package cp.student.restapicp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiCpApplicationTests {

	@Test
	void contextLoads() {
	}

}
