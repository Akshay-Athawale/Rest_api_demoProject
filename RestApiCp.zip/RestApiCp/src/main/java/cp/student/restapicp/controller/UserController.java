package cp.student.restapicp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cp.student.restapicp.domain.User;
import cp.student.restapicp.model.UserDto;
import cp.student.restapicp.serviced.UserService;

@RestController
@RequestMapping("api/v1/user/")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("save/userdata")
	public ResponseEntity<User> saveUserData(@RequestBody UserDto userDto){
		userService.saveUser(userDto);
//		String ss="akshay";
//		if(ss.contains("ak")){
//			System.out.println("yes its present");
//		}
		return new ResponseEntity<User>(HttpStatus.OK);		
	}

}
