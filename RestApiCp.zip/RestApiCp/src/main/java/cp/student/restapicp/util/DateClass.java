package cp.student.restapicp.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import org.springframework.context.annotation.Bean;

public class DateClass {

	public String dateByFormat() {
		LocalDateTime ld = LocalDateTime.now();
		DateTimeFormatter df = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
		String ss = df.format(ld);
		System.out.println(ss);
		return ss;

	}
	
}
