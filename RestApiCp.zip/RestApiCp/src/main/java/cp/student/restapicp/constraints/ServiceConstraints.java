package cp.student.restapicp.constraints;

public class ServiceConstraints {

	public static final String REQUEST_URL = "API URl : %s";
	public static final String REQUEST = "Request : Payload: %s";
	public static final String RESPONSE = "Response : Payload: %s";



}
