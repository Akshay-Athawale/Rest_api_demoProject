package cp.student.restapicp.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import cp.student.restapicp.domain.Student;

@Repository
public interface StudentRepoitory extends JpaRepository<Student, Integer> {

	@Query(value = "SELECT * FROM Student ORDER BY  student_id DESC ", nativeQuery = true)
	public List<Student> findAllByNaiveQuery();
//
//	public void saveByjdbc();
//	public List<Student> finAllByjdbc();

}
