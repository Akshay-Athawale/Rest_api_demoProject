//package cp.student.restapicp.util;
//
//import org.springframework.context.annotation.Bean;
//
//public class Testbean {
//
//	public void Testbean() {
//	System.out.println("test bean method");
//
//	}
//
//}
