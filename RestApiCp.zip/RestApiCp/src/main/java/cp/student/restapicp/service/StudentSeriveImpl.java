package cp.student.restapicp.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import cp.student.restapicp.domain.Student;
import cp.student.restapicp.model.Studentvo;
import cp.student.restapicp.repository.StudentRepoitory;
import cp.student.restapicp.util.DateClass;

@Service
public class StudentSeriveImpl implements StudentService {

	Logger logger = LoggerFactory.getLogger(StudentSeriveImpl.class);
	private String REQUEST = "Request: Payload: %s";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private DateClass dateClass;
	@Autowired
	private StudentRepoitory studentRepoitory;

//	save data api
	@Override
	public void saveStudentData(Studentvo studentvo) {
		logger.info("Entry :: Inside StudentSeriveImpl :: saveStudentData():" + studentvo);
		Student student = new Student();
		BeanUtils.copyProperties(studentvo, student);
		student.setDate(dateClass.dateByFormat());
		logger.info("Exit :: Inside StudentSeriveImpl :: saveStudentData():" + student);

		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setFrom("athawaleakshayb95@gmail.com");
		mailMessage.setTo(studentvo.getEmail());
		mailMessage.setSubject(studentvo.getSubject());
		
		
		studentRepoitory.saveAndFlush(student);
		String m = "registration successfull with id :- " + student.getId() + " and Name :- " + student.getName();
		mailMessage.setText(m);
		javaMailSender.send(mailMessage);
		logger.info("Exit :: Inside StudentSeriveImpl :: saveStudentData() sentMail():" + student);

	}

//	getall data api
	@Override
	public List<Student> getAllStudentData() {
		logger.info("Entry :: Inside StudentServiceImpl :: getAllStudentData():");
//		List<Student> st= studentRepoitory.findAll().stream().filter(e -> e.getId() % 2 == 0).collect(Collectors.toList());
		logger.info("we are in get method of ServiceImpl class");
		List<Student> st = studentRepoitory.findAll().stream()
				.filter(e -> e.getName() != null && e.getName().contains("a")).collect(Collectors.toList());
		logger.info("Exit :: Inside StudentServiceImpl :: getAllStudentData():");
		return st;
	}

//	get all groupBy data api
	public Map<String, List<Student>> getAllStudentBygroupName() {
		logger.info("Entry :: Inside StudentServiceImpl :: getAllStudentBygroupName():");
		Map<String, List<Student>> groupbyname = studentRepoitory.findAll().stream()
				.collect(Collectors.groupingBy(Student::getName, Collectors.toList()));
		logger.info("Exit :: Inside StudentServiceImpl :: getAllStudentBygroupName():");
		return groupbyname;
	}

	// update api
	@Override
	public Student updateStudentById(Studentvo studentvo) {
		logger.info("Exit :: Inside StudentServiceImpl :: updateStudentById():");
		Student student = studentRepoitory.findById((int) studentvo.getId()).orElse(null);
		student.setEmail(studentvo.getEmail());
		student.setName(studentvo.getName());
		student.setNumber(studentvo.getNumber());
		BeanUtils.copyProperties(studentvo, student);
		return studentRepoitory.saveAndFlush(student);

	}

	// delete by id api
	@Override
	public String deleteStudentbyid(int id) {
		studentRepoitory.deleteById(id);
		return "id removed " + id;
	}

//	// save OR Upadate in single api
	@Override
	public Student saveOrUpdate(Studentvo studentvo) {
		Optional<Student> optional = studentRepoitory.findById(studentvo.getId());
		Student student = null;
		if (optional.isPresent()) {
			student = optional.get();
			student.setDate(dateClass.dateByFormat());
		} else {
			student = new Student();
			student.setId(studentvo.getId());
			student.setDate(dateClass.dateByFormat());
		}
		BeanUtils.copyProperties(studentvo, student);
		return studentRepoitory.saveAndFlush(student);

	}

	// read CSV File
	@Override
	public void saveCsv() {
		String line = "";
		try {
			BufferedReader bf = new BufferedReader(new FileReader("src/main/resources/annual.csv"));
			while ((line = bf.readLine()) != null) {
				String[] data = line.split(",");
				Student st = new Student();
				st.setName(data[0]);
				st.setEmail(data[1]);
				st.setNumber(data[2]);
				logger.info("data from csv file");
				studentRepoitory.saveAndFlush(st);
			}
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	@Override
	public String uploadImage(String path, MultipartFile file) throws IOException {
		// file name
		String name = file.getOriginalFilename();

		// full path
		String filePath = path + File.separator + name;

		// create folder if not created

		File f = new File(path);
		if (!f.exists()) {
			f.mkdir();
		}

		// file copy

		Files.copy(file.getInputStream(), Paths.get(filePath));
		return name;
	}

//Using Native Query
	@Override
	public List<Student> getByNaiveQuery() {
		return studentRepoitory.findAllByNaiveQuery();
	}

	String insert = "INSERT INTO cp.Student(student_id,student_name,student_email,student_number,student_date) values (?,?,?,?,?)";

	@Override
	public String saveByJdbc(Studentvo studentvo) {
		Student student = new Student();
		student.setDate(dateClass.dateByFormat());
		BeanUtils.copyProperties(studentvo, student);
		jdbcTemplate.update(insert, student.getId(), student.getName(), student.getEmail(), student.getNumber(),
				student.getDate());
		return "data inserted using jdbc";
	}

	RowMapper<Student> rowMapper = (rs, rowNum) -> {
		Student student = new Student();
		student.setId(rs.getInt("student_id"));
		student.setEmail(rs.getString("student_email"));
		student.setName(rs.getString("student_name"));
		student.setNumber(rs.getString("student_number"));
		return student;
	};

	@Override
	public Student getStudentByIdDByJdbc(int id) {
		logger.info("Entry :: Inside StudentSeriveImpl :: getStudentByIdDByJdbc():");
		String selectbyid = "SELECT * FROM Student WHERE student_id=" + id;
		Student student = null;
		try {
			student = jdbcTemplate.query(selectbyid, (rs, rowNum) -> getMap(rs)).get(0);

		} catch (DataAccessException e) {
			logger.error(e.getMessage(), e);
		}
		return student;
//		RowMapper<Student> rowmapper=new RowMapperImpl();
//		Student st= jdbcTemplate.queryForObject(selectbyid, rowmapper, id);
	}

	private Student getMap(ResultSet rs) {
		logger.info("Entry :: Inside StudentSeriveImpl :: getMap():");
		Student obj = new Student();
		try {
			obj.setId(rs.getInt("student_id"));
			obj.setName(rs.getString("student_name"));
			obj.setEmail(rs.getString("student_email"));
			obj.setNumber(rs.getString("student_number"));
			obj.setDate(rs.getString("student_date"));
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}
		logger.info("Exit :: Inside StudentSeriveImpl :: getAllStudentByjdbc():" + obj);
		return obj;
	}

	//////////////////// Searching by jdbc //////////////////////

	@Override
	public List<Student> getAllStudentByjdbc() {
		String allStudent = "SELECT * FROM Student";
		logger.info("Entry :: Inside StudentSeriveImpl :: getAllStudentByjdbc():");
		List<Student> students = new ArrayList<>();
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(allStudent);
		for (Map row : rows) {
			Student obj = new Student();
			obj.setId((int) row.get("student_id"));
			obj.setName((String) row.get("student_name"));
			obj.setEmail((String) row.get("student_email"));
			obj.setNumber((String) row.get("student_number"));
			obj.setDate((String) row.get("student_date"));
			students.add(obj);
		}
		logger.info("Exit :: Inside StudentSeriveImpl :: getAllStudentByjdbc():" + students);
		return students;

	}

	String query = "select * from student where ";

	@Override
	public Object searchStudentByDeatil(Student student) {
		logger.info("Entry :: Inside StudentService :: searchStudentByDeatil():" + student);

		StringBuilder stringBuilder = new StringBuilder();

		if (student.getId() != 0) {
			stringBuilder.append(" student_id like " + student.getId());
			stringBuilder.append(" and");
		}
		if (student.getName() != null) {

			stringBuilder.append(" student_name like " + "'" + student.getName() + "'");
			stringBuilder.append(" and");
		}
		if (student.getEmail() != null) {

			stringBuilder.append(" student_email like " + "'" + student.getEmail() + "'");
			stringBuilder.append(" and");
		}
		if (student.getNumber() != null) {

			stringBuilder.append(" student_number like " + "'" + student.getNumber() + "'");
			stringBuilder.append(" and");
		}
		String sqlQuery = "";
		if (!stringBuilder.isEmpty()) {
			stringBuilder.replace(stringBuilder.length() - 3, stringBuilder.length(), "");
			sqlQuery = query + stringBuilder;
		}

		Object returnUser = jdbcTemplate.query(sqlQuery, (rs, rowNum) -> userMapFields(rs));
		logger.info("Exit :: StudentServiceimpl :: searchStudentByDetail():" + returnUser);
		return returnUser;
	}

	private Object userMapFields(ResultSet rs) throws SQLException {
		Student student = new Student();
		student.setId(rs.getInt("student_id"));
		student.setName(rs.getString("student_name"));
		student.setEmail(rs.getString("student_email"));
		student.setNumber(rs.getString("student_number"));
		student.setDate(rs.getString("student_date"));
		return student;
	}

	@Override
	public Page<Student> getStudentByPage(int offset, int pageSize) {
		Page<Student> findAllByStudent = studentRepoitory.findAll(PageRequest.of(offset, pageSize));
		System.out.println("findAllByStudent size is : " + findAllByStudent.getSize());
		return findAllByStudent;
	}

	@Override
	public void sendMAil(String to, String subject, String body) {
		logger.info("Exit :: Inside StudentServiceImpl :: sendMAil():");
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		Student student = new Student();
		mailMessage.setFrom("athawaleakshayb95@gmail.com");
		mailMessage.setTo(student.getEmail());
		mailMessage.setSubject(subject);
		mailMessage.setText(body);
		javaMailSender.send(mailMessage);
		logger.info("Exit :: StudentServiceimpl :: sendMAil():" + mailMessage);

	}

}
