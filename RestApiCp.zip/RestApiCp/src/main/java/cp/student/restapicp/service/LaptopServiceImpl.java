package cp.student.restapicp.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cp.student.restapicp.domain.Laptop;
import cp.student.restapicp.domain.User;
import cp.student.restapicp.model.LaptopDto;
import cp.student.restapicp.repository.LaptopRepository;
import cp.student.restapicp.serviced.LaptopService;

@Service
public class LaptopServiceImpl implements LaptopService {

	@Autowired
	private LaptopRepository laptopRepository;

	@Override
	public void saveLaptop(LaptopDto laptopDto) {
		Laptop laptop = new Laptop();	
		BeanUtils.copyProperties(laptopDto, laptop);
		laptopRepository.saveAndFlush(laptop);

	}

}
