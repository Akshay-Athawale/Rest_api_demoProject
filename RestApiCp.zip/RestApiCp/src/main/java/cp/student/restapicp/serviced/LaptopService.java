package cp.student.restapicp.serviced;

import org.springframework.stereotype.Service;

import cp.student.restapicp.domain.Laptop;
import cp.student.restapicp.model.LaptopDto;

@Service
public interface LaptopService {

	public void saveLaptop(LaptopDto laptopDto);
}
