package cp.student.restapicp.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;


public class Studentvo {

	private int id;
	@NotEmpty
	private String name;
	@NotEmpty
	@Email
	private String email;
	@NotEmpty
	private String subject;
	@NotEmpty
	private String number;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	@Override
	public String toString() {
		return "Studentvo [id=" + id + ", name=" + name + ", email=" + email + ", number=" + number + "]";
	}

	

}
