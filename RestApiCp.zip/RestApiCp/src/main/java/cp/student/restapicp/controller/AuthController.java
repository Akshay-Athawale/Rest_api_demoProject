//package cp.student.restapicp.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.authentication.AuthenticationManager;
//
//public class AuthController {
//
//	@Autowired
//	AuthenticationManager authenticationManager;
//	
//
//	
//	
//}
