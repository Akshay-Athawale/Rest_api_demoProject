package cp.student.restapicp.model;

public class OtpResponse {

	private String status;
	private String message;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public OtpResponse(String status, String message) {
		super();
		this.status = status;
		this.message = message;
	}

	public OtpResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "OtpResponse [status=" + status + ", message=" + message + "]";
	}

}
