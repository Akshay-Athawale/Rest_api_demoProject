package cp.student.restapicp.service;

import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cp.student.restapicp.domain.User;
import cp.student.restapicp.model.UserDto;
import cp.student.restapicp.repository.UserRepository;
import cp.student.restapicp.serviced.UserService;

@Service
public class UserServiceImpl implements UserService {

	
	@Autowired
	private UserRepository userRepository;
	@Override
	public void saveUser(UserDto userDto) {
		User user= new User();
		if(userDto!=null)
		{
			BeanUtils.copyProperties(userDto, user);
			userRepository.saveAndFlush(user);
		}else {
			System.out.println("no data found");
		}
		
	}

}
