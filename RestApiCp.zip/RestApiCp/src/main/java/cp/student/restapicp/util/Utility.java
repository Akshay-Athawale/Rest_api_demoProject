package cp.student.restapicp.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Utility {

	private static ObjectMapper mapper = new ObjectMapper();
	
	public static String getString(Object object) {
		String value = "";
		try {
			value = mapper.writeValueAsString(object);
		} catch (Exception e) {

		}
		return value;
	}
}
