package cp.student.restapicp.model;

public class SmsRequest {

	private String number;
	private String message;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public SmsRequest(String number, String message) {
		super(); 
		this.number = number;
		this.message = message;
	}

	@Override
	public String toString() {
		return "SmsRequest [number=" + number + ", message=" + message + "]";
	}

	
}
