package cp.student.restapicp.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cp.student.restapicp.domain.Student;

public class RowMapperImpl implements RowMapper<Student> {

	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		Student student = new Student();
		student.setId(rs.getInt("student_id"));
		student.setName(rs.getString("student_name"));
		student.setEmail(rs.getString("student_email"));
		student.setNumber(rs.getString("student_number"));
		student.setDate(rs.getString("student_date"));
		return student;

	}

}
