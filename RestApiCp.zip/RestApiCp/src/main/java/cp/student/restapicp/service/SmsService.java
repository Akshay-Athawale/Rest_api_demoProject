package cp.student.restapicp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import cp.student.restapicp.model.SmsRequest;
import cp.student.restapicp.model.TwilioProperties;

@Service
public class SmsService {

	private TwilioProperties twilioProperties;

	@Autowired
	public SmsService(TwilioProperties twilioProperties) {
		this.twilioProperties = twilioProperties;
	}

	public String sendSms(SmsRequest request) {
		Message.creator(new PhoneNumber(request.getNumber()),
				new PhoneNumber(twilioProperties.getPhoneNumber()),
				request.getMessage()).create();
		return "message sent successfully";

	}

}
