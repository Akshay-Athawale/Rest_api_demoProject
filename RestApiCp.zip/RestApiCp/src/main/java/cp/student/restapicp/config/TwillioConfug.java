package cp.student.restapicp.config;

import org.springframework.context.annotation.Configuration;

import com.twilio.Twilio;

import cp.student.restapicp.model.TwilioProperties;

@Configuration
public class TwillioConfug {

	private final TwilioProperties tproperties;

	public TwillioConfug(TwilioProperties properties) {
		this.tproperties = properties;
		Twilio.init(properties.getAccountSid(), properties.getAuthToken());
	}

}
