package cp.student.restapicp.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import cp.student.restapicp.domain.Email;
import cp.student.restapicp.domain.Student;
import cp.student.restapicp.model.Studentvo;
import cp.student.restapicp.service.StudentSeriveImpl;
import cp.student.restapicp.util.Utility;

@RestController
@RequestMapping("api/v1")
public class StudentController {

	@Autowired
	private StudentSeriveImpl studentSeriveImpl;

	private static final  Logger LOGGER = LoggerFactory.getLogger(StudentController.class);
	private static final String REQUEST_URL = "API URL : %s";
	private static final String REQUEST = "Request: Payload: %s";
	private static final String RESPONSE = "Response: Payload: %s";
	private static final String CSV_FILE_PATH = "c:/annual.csv";

	@Value("${project.image}")
	private String path;

	@GetMapping("hi")
	public String gt() {
		LOGGER.info("[get message] info message");
		LOGGER.debug("[get message] debug message");
		LOGGER.warn("[get message] warn message");
		LOGGER.error("[get message] error messag");
		return "hello";
	}

	@PostMapping("student/save")
	public ResponseEntity<String> saveStudentData(@Valid @RequestBody Studentvo studentvo) {
		LOGGER.info(String.format(REQUEST_URL, Utility.getString("api/v1/student/save")));
		LOGGER.info(String.format(REQUEST, Utility.getString(studentvo)));
		studentSeriveImpl.saveStudentData(studentvo);
		LOGGER.info(String.format(RESPONSE, Utility.getString(studentvo)));
		return new ResponseEntity<String>("Record Inserted and meassage sent", HttpStatus.OK);

	}

	@GetMapping("/student/getallstudents")
	public ResponseEntity<List<Student>> GetAllStudents() {
		LOGGER.info("Entry :: StudentController :: GetAllStudents():");
		List<Student> allStudentData = studentSeriveImpl.getAllStudentData();
		LOGGER.info("Exit :: StudentController :: GetAllStudents():");
		return new ResponseEntity<List<Student>>(allStudentData, HttpStatus.OK);

	}

	@GetMapping("/student/getallstudentsByGrouping")
	public ResponseEntity<?> GetAllStudentsByGrouping() {
		LOGGER.info("Entry :: StudentController :: GetAllStudentsByGrouping():");
		Map<String, List<Student>> st = studentSeriveImpl.getAllStudentBygroupName();
		LOGGER.info("Exit :: StudentController :: GetAllStudentsByGrouping():");
		return new ResponseEntity<>(st, HttpStatus.OK);
	}

	@PutMapping("student/update")
	public ResponseEntity<Student> updateStudent(@Valid @RequestBody Studentvo studentvo) {
		LOGGER.info("Entry :: StudentController :: updateEmplyee:");
		studentSeriveImpl.updateStudentById(studentvo);
		LOGGER.info("Exit :: StudentController :: updateEmplyee():");
		return new ResponseEntity<Student>(HttpStatus.OK);

	}

	@DeleteMapping("student/delete/{id}")
	public ResponseEntity<String> deleteStudent(@PathVariable int id) {
		LOGGER.info("Entry :: StudentController :: deleteStudent():");
		studentSeriveImpl.deleteStudentbyid(id);
		LOGGER.info("Exit :: StudentController :: deleteStudent():");
		return new ResponseEntity<String>("Record deleted successfully", HttpStatus.OK);

	}

	@PostMapping("student/saveorupdate")
	public ResponseEntity<String> saveOrUpdateStudent(@RequestBody Studentvo studentvo) {
		LOGGER.info("Entry :: StudentController :: saveOrUpdateStudent:");
		studentSeriveImpl.saveOrUpdate(studentvo);
		LOGGER.info("Enxit :: StudentController :: saveOrUpdateStudent:");
		return new ResponseEntity<String>("Record inserted successfully", HttpStatus.OK);
	}

	@PostMapping("student/studentcsv")
	public void readAndSaveCsvFile() {
		LOGGER.info("Entry :: StudentController :: readAndSaveCsvFile():");
		studentSeriveImpl.saveCsv();
	}

	@PostMapping("student/imageUpload")
	public ResponseEntity<String> imageUpload(@RequestParam("image") MultipartFile image) throws IOException {
		studentSeriveImpl.uploadImage(path, image);
		return new ResponseEntity<String>("Image Successfully Uploaded", HttpStatus.OK);
	}

//Using native query using Stream api
	@GetMapping("student/getbyusingnativequery")
	public List<Student> getBynatiQuery() {
		LOGGER.info(String.format(REQUEST_URL, Utility.getString("api/v1/student/getbyusingnativequery")));
		List<Student> collectByNativeQuery = studentSeriveImpl.getByNaiveQuery().stream().collect(Collectors.toList());
		LOGGER.info(String.format(RESPONSE, Utility.getString(collectByNativeQuery)));
		return collectByNativeQuery;
	}

	@PostMapping("student/postbyjdbc")
	public void saveByjdbc(@RequestBody Studentvo studentvo) {
		LOGGER.info("Entry :: StudentController :: saveByjdbc():");
		studentSeriveImpl.saveByJdbc(studentvo);
	}

	@GetMapping("student/getbyid/{id}")
	public Student getStudentByIdDByJdbc(@PathVariable("id") int id) {
		LOGGER.info("Entry :: StudentController :: getByid():");
		Student st = studentSeriveImpl.getStudentByIdDByJdbc(id);
//		return new ResponseEntity<Student>(st, HttpStatus.OK);
		return st;
	}

	@GetMapping("student/getallbyjdbc")
	public List<Student> getAllByjdbc() {
		LOGGER.info("Entry :: StudentController :: getAllByjdbc():");
		return studentSeriveImpl.getAllStudentByjdbc();
	}

	@GetMapping("student/getbysearchdetails")
	public Object searchStudentByDetails(@RequestBody Student student) {
		LOGGER.info("Entry :: StudentController :: searchStudentByDetails():");
		return studentSeriveImpl.searchStudentByDeatil(student);

	}

	@GetMapping("student/pagination/{offSet}/{pageSize}")
	public ResponseEntity<Page<Student>> getStudentByPage(@PathVariable int offSet, @PathVariable int pageSize) {
		LOGGER.info("Entry :: StudentController :: getStudentByPage():");
		Page<Student> studentByPage = studentSeriveImpl.getStudentByPage(offSet, pageSize);
		return new ResponseEntity<Page<Student>>(studentByPage, HttpStatus.OK);
	}

	@PostMapping("student/sendmail")
	public ResponseEntity<Email> sendMail(@RequestBody Email email) {
		LOGGER.info(String.format(REQUEST_URL, Utility.getString("")));
		LOGGER.info(String.format(REQUEST, Utility.getString(email)));
		studentSeriveImpl.sendMAil(email.getTo(), email.getSubject(), email.getBody());
		LOGGER.info(String.format(RESPONSE, Utility.getString(email)));
		return new ResponseEntity<Email>(email, HttpStatus.OK);

	}

}
