package cp.student.restapicp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.twilio.rest.api.v2010.account.Message;

import cp.student.restapicp.model.SmsRequest;
import cp.student.restapicp.service.SmsService;

@RestController
@RequestMapping("api/v1/")
public class SmsController {

	@Autowired
	private SmsService service;

	@PostMapping("sendsms")
	public ResponseEntity<String> sendSms(@RequestBody SmsRequest request) {
		 String sendSmsResponse = service.sendSms(request);
		return new ResponseEntity<String>(sendSmsResponse,HttpStatus.OK);

	}
}
