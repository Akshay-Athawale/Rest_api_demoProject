package cp.student.restapicp.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import cp.student.restapicp.domain.Student;
import cp.student.restapicp.model.Studentvo;

@Service
public interface StudentService {

	void saveStudentData(Studentvo studentvo);

	List<Student> getAllStudentData();

	public String deleteStudentbyid(int id);

	public Student updateStudentById(Studentvo studentvo);

	Student saveOrUpdate(Studentvo studentvo);

	public void saveCsv();

	String uploadImage(String path, MultipartFile file) throws IOException;

	public List<Student> getByNaiveQuery();

	public Page<Student> getStudentByPage(int offset, int pageSize);

//////////////////////       JDBC    /////////////////////////
	public String saveByJdbc(Studentvo studentvo);

	Student getStudentByIdDByJdbc(int id);

	public List<Student> getAllStudentByjdbc();

	public Object searchStudentByDeatil(Student Student);

	public void sendMAil(String to, String subject, String body);

}
