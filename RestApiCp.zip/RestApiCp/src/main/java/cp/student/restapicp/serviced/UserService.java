package cp.student.restapicp.serviced;

import org.springframework.stereotype.Service;

import cp.student.restapicp.domain.User;
import cp.student.restapicp.model.UserDto;

@Service
public interface UserService {
	
	public void saveUser(UserDto user);
}
